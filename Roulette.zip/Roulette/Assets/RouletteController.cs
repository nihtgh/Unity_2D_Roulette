﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RouletteController : MonoBehaviour
{
    int sum = 0;
    float rotSpeed = 0;
    bool flg = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0)) {
            sum++;
            if (sum == 2) {
                flg = true;
            }
            if (sum == 1) {
                this.rotSpeed = 10;
            }
            
        }
        if (flg) {
            this.rotSpeed *= 0.995f;
        }
        transform.Rotate(0, 0, this.rotSpeed);
        if (sum == 3) {
            sum = 1;
            this.rotSpeed = 10;
            flg = false;
        }
    }
}
